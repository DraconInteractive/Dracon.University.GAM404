Scenes of interest are RPGStatisticsAssignment, and RPGStatisticsAssignmentMenu. 
If you have trouble locating, they are entered in the build menu. 

Scripts of interest
- StatisticsController.cs
- CharacterSlotUI.cs
- CharacterDescUI.cs
- MenuController.cs
- TeamContainer.cs

These should all be contained within the namespace "Final"

All files are also downloadable from https://github.com/RarCeth/GAM404VC (although, if you're reading this then you're either already there or you already downloaded directly, so not as helpful advice here :P)

Enjoy!
Peter Carey